<?php
namespace App\Models;

use CodeIgniter\Model;

class Model_lab extends Model
{
    public function select($key,$val)
    {
        $table = $this->db->table('order_lab');
        if($key == 'documentdate')
        {
            $table->where('tgl_order',$val);
        }
        else
        {
            $table->where('no_rm',$val);
        }
        $query = $table->get();
        return $query->getResultArray();
    }

    public function insert_lab($request)
    {
        $table = $this->db->table('lab_hasil');
        $table->insert($request);
    }
}