<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\HTTP\Request;
//use Firebase\JWT\JWT;
use App\Models\Model_lab;


class Lab extends ResourceController
{
    // fungsi untuk mengambil data
    public function select()
    {
        // mengambil header username dan password
        $headers = apache_request_headers();
        // mendapatkan url
        $path = $this->request->getPath();
        $param = explode('/', $path);

        // pengecekan apakah user dan pass sudah diisi
        if (!isset($headers['x-username']) || !isset($headers['x-password'])) {
            return $this->respond([
                "metadata" => [
                    "message" => "Username atau password belum dimasukkan",
                    "code" => 400
                ]
            ], 400);
        }

        // pengecekan apakah user dan pass benar
        if ($headers['x-username'] == getenv('x_username') && $headers['x-password'] == getenv('x_password')) {
            // koneksi ke model
            $model = new Model_lab();
            $data = $model->select($param[1], $param[2]);

            // pengecekan jika tidak ada data ditemukan
            if (count($data) == 0) {
                return $this->respond([
                    "metadata" => [
                        "message" => "Data untuk " . $param[1] . " " . $param[2] . " tidak ditemukan",
                        "code" => 404,
                    ]
                ], 404);
            }

            // jika data ditemukan
            return $this->respond([
                "metadata" => [
                    "message" => "success",
                    "code" => 200,
                    "response" => $data
                ]
            ], 200);
        }

        // jika user atau pass salah
        return $this->respond([
            "metadata" => [
                "message" => "Username atau password salah",
                "code" => 400
            ]
        ], 400);
    }

    public function insert()
    {
        // mengambil header username dan password
        $headers = apache_request_headers();

        // mendapatkan url
        $path = $this->request->getPath();
        $param = explode('/', $path);

        // mendapatkan request user
        $request = json_decode(json_encode($this->request->getVar()), true);

        $validation = \Config\Services::validation();
        $validation->setRules($this->rules_insert());

        // pengecekan apakah user dan pass sudah diisi
        if (!isset($headers['x-username']) || !isset($headers['x-password'])) {
            return $this->respond([
                "metadata" => [
                    "message" => "Username atau password belum dimasukkan",
                    "code" => 400
                ]
            ], 400);
        }

        // pengecekan apakah user dan pass benar
        if ($headers['x-username'] == getenv('x_username') && $headers['x-password'] == getenv('x_password')) {
            // pengecekan apakah ada request yang terlewat
            $isValid = $validation->withRequest($this->request)->run();
            if ($isValid == false) {
                $get_error = $validation->getErrors();
                // assosiative array to normal array
                $error = array_values($get_error);
                return $this->respond([
                    "metadata" => [
                        "message" => $error[0],
                        "code" => 201
                    ]
                ], 201);
            }
            // koneksi ke model
            $model = new Model_lab();

            try {
                $model->insert_lab($request);
                // respon ketika berhasil
                return $this->respond([
                    "metadata" => [
                        "message" => "success",
                        "code" => 200,
                        "request" => $request
                    ]
                ], 200);
            } catch (\Throwable $th) {
                // respon ketika gagal insert
                return $this->respond([
                    "metadata" => [
                        "message" => "Terjadi kesalahan saat proses insert",
                        "code" => 500,
                    ]
                ], 500);
            }
        }

        // jika user atau pass salah
        return $this->respond([
            "metadata" => [
                "message" => "Username atau password salah",
                "code" => 400
            ]
        ], 400);
    }

    // rules untuk proses insert
    private function rules_insert()
    {
        $rules =
            [
                'no_order' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'no_order tidak boleh kosong'
                    ]
                ],
                'no_lab' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'no_lab tidak boleh kosong'
                    ]
                ],
                'no_registrasi' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'no_registrasi tidak boleh kosong'
                    ]
                ],
                'no_urut' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'no_urut tidak boleh kosong'
                    ]
                ],
                'kode_pemeriksaan' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'kode_pemeriksaan tidak boleh kosong'
                    ]
                ],
                'nama_pemeriksaan' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'nama_pemeriksaan tidak boleh kosong'
                    ]
                ],
                // 'unit' => [
                //     'rules' => 'required',
                //     'errors' => [
                //         'required' => 'unit tidak boleh kosong'
                //     ]
                // ],
                'normal' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'normal tidak boleh kosong'
                    ]
                ],
                'hasil' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'hasil tidak boleh kosong'
                    ]
                ],
                'flag' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'flag tidak boleh kosong'
                    ]
                ],
                'tgl_jam_insert' => [
                    'rules' => 'required|valid_date[Y-m-d]',
                    'errors' => [
                        'required' => 'tgl_jam_insert tidak boleh kosong',
                        'valid_date' => 'format tgl_jam_insert harus Y-m-d'
                    ]
                ],
                'flag_ambil' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'flag_ambil tidak boleh kosong'
                    ]
                ],
                'tgl_jam_ambil' => [
                    'rules' => 'required|valid_date[Y-m-d]',
                    'errors' => [
                        'required' => 'tgl_jam_ambil tidak boleh kosong',
                        'valid_date' => 'format tgl_jam_ambil harus Y-m-d'
                    ]
                ],
                'type' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'type tidak boleh kosong'
                    ]
                ],
                'no_rm' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'no_rm tidak boleh kosong'
                    ]
                ],
                'tgl_daftar' => [
                    'rules' => 'required|valid_date[Y-m-d]',
                    'errors' => [
                        'required' => 'tgl_daftar tidak boleh kosong',
                        'valid_date' => 'format tgl_daftar harus Y-m-d'
                    ]
                ],
                'tgl_hasil' => [
                    'rules' => 'required|valid_date[Y-m-d]',
                    'errors' => [
                        'required' => 'tgl_hasil tidak boleh kosong',
                        'valid_date' => 'format tgl_hasil harus Y-m-d'
                    ]
                ],
                'kode_sir' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'kode_sir tidak boleh kosong'
                    ]
                ],
            ];

        return $rules;
    }

    public function not_found()
    {
        // ketika url tidak sesuai dengan yang ada pada halaman config/routes
        return $this->respond([
            "metadata" => [
                "message" => "Url tidak tersedia",
                "code" => 404
            ]
        ], 404);
    }
}
